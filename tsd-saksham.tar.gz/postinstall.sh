#!/bin/sh
#composer install
#chmod -R g+w ./storage
#php artisan migrate
#php artisan db:seed
#php artisan build:labels
mkdir -m 0775 -p public/uploads
mkdir -m 0775 -p public/uploads/tmp