<?php

function isSecure()
{
	if(isset($_SERVER['HTTPS']) && isset($_SERVER['SERVER_PORT']))
		return ( ! empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || $_SERVER['SERVER_PORT'] == 443;
	else
		return false;
}


$protocol	=	isSecure() ? 'https' : 'http';

$config		=	[];

switch(getenv('APP_ENV'))
{
	case 'production':
        $config['timezone']	=	'UTC';
        $config['locale']	=	'en_US';
        $config['key']		=	env('APP_KEY', '0Ll3gEkiP0py920p7zwhqKn6lEluv206');
        $config['cipher']	=	MCRYPT_RIJNDAEL_128;
        $config['log']		=	'daily';

        $config['facebook']	=	[
									'app_id' => '460748070982120',
									'app_secret' => 'de8e42b3fa6f2f4e0a8436ead129024e',
									'version' => 'v2.8',
									'namespace'	=>	'tsd_saksham',
                                    'url'=> $protocol.'://profilepic.saksham2017.org/',
									'auth_scope' => 'email',
									'developers' =>   '1249623098465530'
								];

		$config['twitter']	=	[
									'consumer_key' => 'hUsK1YUZYT0SmBQs2j2HasYrQ',
									'consumer_secret' => '1jvjM8RcpsnL49U1W7oBe7qqvtirrPMod8WzXaMqQVdwE1qqGL'
								];

        $config['cb']		=	$_SERVER['REQUEST_TIME'];
        $config['ga_id']	=	'UA-91563047-1';
	break;

	case 'staging':
        $config['timezone']	=	'UTC';
        $config['locale']	=	'en_US';
        $config['key']		=	env('APP_KEY', 'SomeRandomString');
        $config['cipher']	=	MCRYPT_RIJNDAEL_128;
        $config['log']		=	'daily';

        $config['facebook']	=	[
									'app_id' => '463354054054855',
									'app_secret' => '7c9858bd9e9a76e83becf968083adb21',
									'version' => 'v2.8',
									'namespace'	=>	'tsd_saksham_stg',
                                    'url'=> $protocol.'://tsd-saksham.eu-staging.kacdn.net/',
									'auth_scope' => 'email',
									'developers' =>   '1249623098465530'
								];

		$config['twitter']	=	[
									'consumer_key' => 'bkm8EUyIUDJz1My1CkkPYXozV',
									'consumer_secret' => 'rAFHwKiJbxmKzG58lxBX1rAFh93d2UBPHRpNOK9TFvYvxwwjWo'
								];

        $config['cb']		=	$_SERVER['REQUEST_TIME'];
        $config['ga_id']	=	'UA-91545594-1';
	break;

	case 'development':
        $config['timezone']	=	'UTC';
        $config['locale']	=	'en_US';
        $config['key']		=	env('APP_KEY', 'SomeRandomString');
        $config['cipher']	=	MCRYPT_RIJNDAEL_128;
        $config['log']		=	'daily';

        $config['facebook']	=	[
									'app_id' => '463350814055179',
									'app_secret' => '57b4c3a48d2a42f14dbf788574e12027',
									'version' => 'v2.8',
									'namespace'	=>	'tsd_saksham_dev',
                                    'url'=> $protocol.'://tsd-saksham.dev.krds.com/',
									'auth_scope' => 'email',
									'developers' =>   '1249623098465530'
								];

		 $config['twitter']	=	[
									'consumer_key' => 'WvB3dms0UPLYIGxW8Kp9wolrf',
									'consumer_secret' => 'L80kC7LrbtyWtCI7X3CndwzWmQi6hUaDYTm1UXWwLx9qEmcMlS'
								];

        $config['cb']		=	$_SERVER['REQUEST_TIME'];
        $config['ga_id']	=	'';
	break;

	case 'local':
		$config['timezone']	=	'UTC';
		$config['locale']	=	'en_US';
		$config['key']		=	env('APP_KEY', 'SomeRandomString');
		$config['cipher']	=	MCRYPT_RIJNDAEL_128;
		$config['log']		=	'daily';

		$config['facebook']	=	[
									'app_id' => '463355144054746',
									'app_secret' => '255b988e60fd16cf8c14e60e28f2ea78',
									'version' => 'v2.8',
									'namespace'	=>	'tsd_saksham_local',
                                    'url'	=> $protocol.'://localhost:5000/',
									'auth_scope' => 'email',
									'developers' =>   '1249623098465530'
								];

		$config['twitter']	=	[
									'consumer_key' => 'yvqcqqeX4imcKFOKii8MUhCQH',
									'consumer_secret' => 'W55qOxXZI2fYpF7RFqttDP3HFYEtfgWEKqfwGAg7ZZJDS1vRtD'
								];

		$config['cb']		=	$_SERVER['REQUEST_TIME'];
		$config['ga_id']	=	'';
	break;
}

$config['debug']	=	env('APP_DEBUG');


if(getenv('APP_ENV') == 'production')
date_default_timezone_set('Asia/Singapore');

$config['timestamp']            =   strtotime('now Asia/Singapore');
$config['today_date']           =   strtotime('today Asia/Singapore');
return $config;
