<!DOCTYPE html>
<html lang="en" <?php if($asset == 'home'): ?> class="landing loading" <?php else: ?> class="loading" <?php endif; ?> >
	<head>
		<meta charset="UTF-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<title><?php echo e(trans('messages.app_title')); ?></title>
		<link rel="shortcut icon" href="<?php echo e(conf('facebook.url')); ?>assets/img/favicon.ico" type="image/icon">
		<?php if(device('isMobile')): ?>
			<meta name="viewport" content="width=device-width,user-scalable=no,maximum-scale=1,initial-scale=1">
		<?php else: ?>
			<meta name="viewport" content="width=device-width,user-scalable=no,maximum-scale=1,initial-scale=1">
		<?php endif; ?>
		<meta property="fb:app_id" content="<?php echo e(conf('facebook.app_id')); ?>" />
		<link href="<?php echo e(conf('facebook.url')); ?>assets/style/build/main.css" rel="stylesheet">

		<script>
			var Env = {
				core	:	{
					cb	:	"<?php echo e(conf('cb')); ?>",
					env :	"<?php echo e(getenv('APP_ENV')); ?>",
					str :   "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/="
				},
				kite: {
					env: {
						dev		:	'development',
						staging	:	'staging',
						prod	:	'production'
					}
				},
				device 	: 	{
					is_mobile	: 	("<?php echo e(device('isMobile')); ?>" === "1"),
					is_tablet	: 	("<?php echo e(device('isTablet')); ?>" === "1"),
					lg_pad		:	("<?php echo e(device('lg_pad')); ?>" === "1")
				},
				fb 		: 	{
					appId			: 	"<?php echo e(conf('facebook.app_id')); ?>",
					version			: 	"<?php echo e(conf('facebook.version')); ?>",
					locale			:	"<?php echo e(conf('locale')); ?>",
					callbackUrl		: 	"<?php echo e(conf('facebook.url')); ?>",
					signedRequest	: 	"<?php echo e(fb()->signed_request); ?>",
					userId			: 	"<?php echo e(fb()->user); ?>",
					mode			:	'<?php echo e(fb()->app_mode); ?>',
					authScope		:	"<?php echo e(conf('facebook.auth_scope')); ?>",
					useCookie		: 	true,
                    timestamp       :   "<?php echo e(conf('timestamp')); ?>",
                    today_date      :   "<?php echo e(conf('today_date')); ?>"
				},
				ga		:	{
					id	:	"<?php echo e(conf('ga_id')); ?>"
				},
				i18n	:	{
					tw_share_top_title	:	"<?php echo e(trans('messages.tw_share_top_title')); ?>",
					fb_share_title	:	"<?php echo e(trans('messages.fb_share_title')); ?>",
					fb_share_discription : "<?php echo e(trans('messages.fb_share_discription')); ?>"
				},
                asset: "<?php echo e($asset); ?>"
			};

		</script>

        <script src="/assets/js/preloadjs-0.6.2.min.js"></script>
		<?php if(getenv('APP_ENV') != 'production'): ?>
			
		<?php else: ?>
			<script async src="//www.google-analytics.com/analytics.js"></script>
		<?php endif; ?>

        <script src="/assets/js/bundle/main.js?v=<?php echo e(conf('cb')); ?>"></script>
        
	</head>

	<body>
		<div class="container site">
			<div class="logo">
				<div class="MinistryLogo">
				<img class="profilepic1" alt="profilepic" src="assets/img/mpng.png">
				</div>
				<div class="sakshamLogo">
				<img class=" profilepic" alt="profilepic" src="assets/img/saksham.png">
				</div>
				<div class="pcraLogo">
				<img class="img-responsive profilepic1" alt="profilepic" src="assets/img/pcra.png">
				</div>
			</div>

			<div class="container contentBlock" id="container">
				<?php echo $__env->yieldContent('content'); ?>
			</div>
		</div>

		<!-- div id="terms_dialog" class="kdialog cs termsDialog" style="display: none;">
			<a href="#" data-action="close" class="closeBtn">X</a>
			<h3><?php echo e(trans('messages.home_terms_title')); ?></h3>
            <div class="content">
					<ol>
	                <?php echo trans('messages.home_terms_desc_1'); ?>

						 <?php echo trans('messages.home_terms_desc_2'); ?>

	                <?php echo trans('messages.home_terms_desc_3'); ?>

	                <?php echo trans('messages.home_terms_desc_4'); ?>

	                <?php echo trans('messages.home_terms_desc_5'); ?>

				 	</ol>
            </div>

		</div -->
		
	</body>
</html>
