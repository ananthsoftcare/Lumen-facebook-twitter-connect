<?php $__env->startSection('twitter_callback'); ?>

<div id="message"></div>
<script>
    var profile_image = "<?php echo e($profile_image); ?>";
    var share_image = "<?php echo e($share_image); ?>";
    var message = "<?php echo e($message); ?>";
    var id = "<?php echo e($id); ?>";
    
    document.getElementById('message').innerHTML = message;

    window.opener.twitterCallback(profile_image, share_image, id);
    
    setTimeout(function(){
        window.close();
    }, 1000);
    
</script>
<?php $__env->stopSection(); ?>