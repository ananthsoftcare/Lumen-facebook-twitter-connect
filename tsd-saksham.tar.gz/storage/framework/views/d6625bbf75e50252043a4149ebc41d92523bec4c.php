<?php $__env->startSection('content'); ?>
	<div id="home">		
		<h1><?php echo trans('messages.fo_home_title'); ?></h1>
        <div class="uploadBlock">
          <div class="imgBlock">
            <img class="img-responsive profilepic1" alt="profilepic" src="assets/img/profile.jpg">
			<div class="loader"><span></span></div>
          </div>
          <div class="connectBtn">
            <a href="#" id="btn_connect" class="btn"><i class="facebook"></i><span><?php echo e(trans('messages.fo_button_connect')); ?></span></a>
            <a href="#" id="btn_twitter_connect" class="btn twt"><i class="twitter"></i><span><?php echo e(trans('messages.fo_button_connect')); ?></span></a>
          </div>
        </div>
	</div>

	<div id="share" style="display:none;">
		<h1><?php echo trans('messages.fo_download_title'); ?></h1>
		<div class="uploadBlock">
			<div class="imgBlock">
				<img class="img-responsive profilepic1" id="user_image" alt="profilepic" src="assets/img/profile.jpg">
				<div class="shareBlock">
				<a href="#" target="_blank" id="fb_share" class="facebook"></a>
				<a href="#" target="_blank" id="tw_share" class="twitter"></a>
				<span class="sh"><?php echo e(trans('messages.fo_label_share')); ?></span>
				</div>
			</div>
			<div>
				<a href="#" id="download" class="btn downLoad">
				<i class="download"></i>
				<span><?php echo e(trans('messages.fo_button_download')); ?></span>
				</a>
			</div>
		</div>		
	</div>

	<div id="dialog_auth" class="kdialog fbdialog" style="display: none;">
		<h3><?php echo e(trans('messages.home_auth_title')); ?></h3>
		<p><?php echo e(trans('messages.home_auth_description')); ?></p>
		<div class="actions">
			<a href="#" id="btn_auth_continue" data-action="continue" class="continue yellow"><?php echo e(trans('messages.home_auth_continue_button')); ?></a>
			<a href="#" id="btn_auth_cancel" data-action="cancel" class="cancel yellow"><?php echo e(trans('messages.home_auth_cancle_button')); ?></a>
		</div>
	</div>
    
	<script>
    
        window.error        =   "<?php echo e($error); ?>";
        window.access_code =   "<?php echo e($access_token); ?>";

        if(typeof view != 'undefined')
            view.asset  =   'home';
    </script>

    


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', ['asset' => 'home'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>