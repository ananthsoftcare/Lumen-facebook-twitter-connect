<!DOCTYPE html>
<html>
    <head>        
        <title><?php echo e($details['title']); ?></title>
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:site" content="@tsdsaksham" />
        <meta name="twitter:creator" content="@FBAppsAccount" />
        <meta name="twitter:title" content="<?php echo e($details['title']); ?>" />
        <meta name="twitter:description" content="<?php echo e($details['description']); ?>" />
        <meta name="twitter:image:src" content="<?php echo e($details['img_url']); ?>" />
    </head>
    <body>
        <script type="text/javascript">
            window.location.href = "<?php echo e(conf('facebook.url')); ?>";
        </script>
    </body>
</html>