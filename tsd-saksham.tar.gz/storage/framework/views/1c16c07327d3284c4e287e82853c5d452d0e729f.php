<?php $__env->startSection('twitter_callback'); ?>

<div id="message"></div>
<script>
    var resp = "<?php echo e($amazon_image); ?>";
    var message = "<?php echo e($message); ?>";
    
    document.getElementById('message').innerHTML = message;

    window.opener.twitterCallback(resp, 'twitter_form');
    
    setTimeout(function(){
        window.close();
    }, 1000);
    
</script>
<?php $__env->stopSection(); ?>