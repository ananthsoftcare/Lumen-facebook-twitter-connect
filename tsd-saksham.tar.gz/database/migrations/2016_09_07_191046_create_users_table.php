<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateUsersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('ts_users', function(Blueprint $table)
        {
            $table->increments('id');
            $table->bigInteger('id_user')->unique();
            $table->string('first_name');
            $table->string('last_name');
            $table->string('screen_name');
            $table->string('email');
            $table->tinyInteger('is_optin');
            $table->string('gender', 30);
            $table->string('ip', 15);
            $table->string('ua', 1000);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
    }
}
