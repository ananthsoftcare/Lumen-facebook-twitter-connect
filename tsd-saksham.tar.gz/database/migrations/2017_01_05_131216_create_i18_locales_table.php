<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateI18LocalesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('i18n_locales', function (Blueprint $table) {
            $table->increments('id'); 
            $table->string('locale', 5);
            $table->tinyInteger('is_default')->nullable()->default(null);
            $table->tinyInteger('is_enabled')->nullable()->default(null);
            $table->string('fb_locale', 5);
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('i18n_locales');
    }
}
