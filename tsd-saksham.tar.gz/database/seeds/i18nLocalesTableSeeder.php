<?php

use Illuminate\Database\Seeder;

class i18nLocalesTableSeeder extends Seeder
{

    /**
     * Auto generated seed file
     *
     * @return void
     */
    public function run()
    {
        \DB::table('i18n_locales')->delete();

        \DB::table('i18n_locales')->insert(array(
            array(
                "id" => 1, 
                "locale" => "en_US", 
                "is_default" => 1, 
                "is_enabled" => 1, 
                "fb_locale" => "en_US")
        ));
    }
}
