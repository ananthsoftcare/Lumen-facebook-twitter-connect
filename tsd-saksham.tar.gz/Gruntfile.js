var uniqid = require('uniqid');
var path = require('path');

module.exports = function(grunt) {

	// Project configuration.
	grunt.initConfig({
		pkg: grunt.file.readJSON('package.json'),
		browserify: {
			'public/assets/js/bundle/main.js' : 'public/assets/js/main.js',
			front: {
                expand: true,
                cwd: 'public/assets/js/',
                src: ['**/*.js', '!bundle/**/*', '!lib/*js'],
                dest: 'public/assets/js/bundle',
                ext: '.js'
            },
			client:
			{
				src: [
					'public/assets/js/index.js'
				],
				dest: 'public/assets/js/bundle/common.js',
				options: {
					plugin: [['factor-bundle',
					{
						outputs: [
							'public/assets/js/bundle/index.js'
						]
					}]]
				}
			}
		},

        watch: {
			css: {
				files: ['public/assets/style/*.less'],
				tasks: ['less:build']
			},
			 js: {
               files: [
                   'public/assets/js/**/*.js',
                   '!public/assets/js/bundle/**/*.js',
                   '!public/assets/js/lib/*.js'
               ],
               tasks: ['newer:browserify:front']
			},

			options: {
				atBegin: true
			}
		},

		less: {
			options: {
				paths: ["public/assets/style"],
				plugins: [
					new (require('less-plugin-autoprefix'))({browsers: ["chrome > 10", "firefox > 10", "ie > 7", "android > 2", "ios > 5"]}),
					new (require('less-plugin-clean-css'))({})
				]
			},
			build: {
				files: {
					"public/assets/style/build/main.css": ["public/assets/style/main.less"],
					"public/assets/style/build/toolbox.css": ["public/assets/style/lib/toolbox/main.less"],
					"public/assets/style/build/kdialog.css": ["public/assets/style/lib/kdialog.less"]
				}
			}
		},

		postcss: {
            options: {
                map: true,
                processors: [
                    require('autoprefixer')({
                        browsers: ["chrome > 10", "firefox > 10", "ie > 7", "android > 2", "ios > 5"]
                    })
                ]
            },
            dist: {
                src: 'public/assets/style/build/*.css'
            }
        },

		cssmin: {
			build: {
				files: {
					'public/assets/style/build/main.css': 'public/assets/style/build/main.css'
					
				}
			}
		},

		cachebreaker: {
			dev: {
				options: {
					match: ['.jpg', '.png', '.css', '.js'],
					replacement: function (){
						return Math.ceil(Date.now() / 1000);	//Micro Seconds removed
					}
				},
				files: {
					src: [
							'public/assets/json/assets.json'
						]
				}
			}
		},

		php: {
            development: {
                options: {
                    hostname: '0.0.0.0',
                    port: 6000,
                    base: 'public',
                    keepalive: false
                }
            }
        },

		uglify: {
			app: {
				files: [{
					expand: true,
					cwd: 'public/assets/js/bundle',
					src: '**/*.js',
					dest: 'public/assets/js/bundle'
				}]
			}
		},

	});

	grunt.registerTask('serve', ['php:development', 'watch']);


	grunt.loadNpmTasks('grunt-browserify');
	grunt.loadNpmTasks('grunt-cache-breaker');
    grunt.loadNpmTasks('grunt-contrib-uglify');
	grunt.loadNpmTasks('grunt-contrib-less');
	grunt.loadNpmTasks('grunt-contrib-cssmin');
	grunt.loadNpmTasks('grunt-contrib-watch');
	grunt.loadNpmTasks('grunt-postcss');
	grunt.loadNpmTasks('grunt-php');
 	grunt.loadNpmTasks('grunt-newer');

	grunt.registerTask('default', [
		'browserify',
		'less:build',
		//'cachebreaker',
		//'cssmin',
		//'uglify'
	]);
};
