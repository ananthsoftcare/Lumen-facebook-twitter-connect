<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Symfony\Component\Console\Input\InputOption;
use Illuminate\Support\Facades\DB;

class BuildLabelsCommand extends Command {
    /**
     * The console command name.
     *
     * @var string
     */
    protected $name = 'build:labels';

	protected $labelPath;

	protected $localeTable = 'i18n_locales';

	protected $labelTable = 'i18n_locales_labels';

	protected $locales = [];

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = "This is used to build the labels for translations from the DB";
    /**
     * Execute the console command.
     *
     * @return void
     */
    public function fire()
    {

		$this->labelPath = base_path().'/resources/lang';

		$this->getLocales();

		if(empty($this->locales))
		{
			$this->error("No locales for this project");
			return;
		}

		foreach($this->locales as $locale){
			$labels =	$this->getLabels($locale);
			$this->writeToLabelFile($locale, $labels);
		}

    }
    /**
     * Get the console command options.
     *
     * @return array
     */
    protected function getOptions()
    {
        return array(

			array('lang', null, InputOption::VALUE_OPTIONAL, 'The specific language you want to build label for')

        );
    }



	private function getLocales()
	{
		if(!$this->hasTable($this->localeTable))
		      return;

		$this->locales = DB::table($this->localeTable)
				->where('is_enabled','1')
				->pluck('locale');
	}

	private function getLabels($locale)
	{
        $labels =   [];

        if( ! $this->hasTable($this->labelTable))
            return;

        $data   =   DB::table($this->labelTable)->select('id_label', $locale)->get();
        $data   =   json_decode(json_encode($data), true);

		array_map(function($item) use (&$labels, $locale) {
			$labels[$item['id_label']] =   $item[$locale] ? : $item['id_label'];
		}, $data);

		return $labels;
	}

	private function writeToLabelFile($locale,$content)
	{
		$groupName  = 'messages';
		$folderpath = $this->labelPath.'/'.$locale;
		$filePath	= $folderpath.'/'.$groupName.'.php';
		$data	= '';

		if (!file_exists($folderpath))
		{
			mkdir($folderpath);
			$this->info("Created the locale folder {$locale}");
		}
		// new feature to get the new labels that have been created / modified
		$labelDiff = $this->getLabelDifferences($content,$locale,$groupName);
		if(empty($labelDiff))
            return false;
		$exportedContent =  var_export($content, true);

		$data .= sprintf(
                "<?php \n return \n %s;",
                 $exportedContent
            );
		file_put_contents($filePath, $data);
		$this->info("Created the labels for:  {$locale}");

	}

	private function getLabelDifferences($content, $locale, $groupName)
	{
		$loader = new \Illuminate\Translation\FileLoader(app('files'), $this->labelPath);
		$oldLabels = $loader->load($locale,$groupName);

		$newLabels = [];

		if(!empty($oldLabels) && count($oldLabels) != 0)
            $newLabels	= array_diff_assoc($content,$oldLabels);
        else
            $newLabels  =   $content;


		if(!empty($newLabels))
		{
			echo 'New labels updated / modified';
			echo '<pre>';
			print_r($newLabels);
		}
		else
		echo 'No modified labels';

		return $newLabels;
	}

	protected function hasTable($table)
    {
        return \Schema::connection(config('database.default'))->hasTable($table);
    }
}
