<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class User extends Model
{

	protected $table = 'ts_users';
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
       'id_user', 'first_name', 'last_name', 'screen_name', 'email', 'friends_count', 'gender', 'ip', 'ua'
    ];

    

	public function checkEmailAlreadyExists($email)
	{
		$user	=	$this
						->where('email', '=', $email)
						->first();

		return ! empty($user);
	}

   
}
