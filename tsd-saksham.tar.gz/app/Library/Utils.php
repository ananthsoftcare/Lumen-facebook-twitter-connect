<?php
namespace App\Library;

use Imagick;
use Aws\S3\S3Client;
use GuzzleHttp\Client;

class Utils 
{
    public function getUserFacebookDetails()
	{
		$id_fb_user		=	app('facebook')->user;

		$accessToken	=	conf('facebook.app_id').'|'.conf('facebook.app_secret');

		$fields			=	['email', 'first_name', 'last_name', 'gender'];
		$ret			=	array_fill_keys($fields, null);

		if( ! empty($id_fb_user))
		{
			$q_graph	=	app('facebook')->getGraph('/'.$id_fb_user.'?fields='.implode(',', $fields), $accessToken);

			if(is_object($q_graph))
			{
				foreach($fields as $field)
				{
					if(isset($q_graph->$field))
					    $ret[$field]	=	$q_graph->$field;
				}
			}
		}

		return $ret;
	}

	public function saveImage($id_user, $img_url)
	{
		$img_frame = app()->basePath('public/assets/img/frame.png');
		$img_share = app()->basePath('public/assets/img/fbshare.jpg');
		$tmp_path = app()->basePath('public/uploads/tmp/'.$id_user.'.jpg');
		$img_target_path = app()->basePath('public/uploads/'.$id_user.'.png');
		$img_share_target_path = app()->basePath('public/uploads/'.$id_user.'_share.png');
		
		$tmp_img = self::saveFileFromURL($img_url, $tmp_path);

		$image_app	=	new \Imagick($tmp_path);
		$image_app1	=	new \Imagick($img_frame);
		$image_app->thumbnailImage(320, 320, false);
		//$image_app1->thumbnailImage(320, 320, false);
		$image_app->compositeImage($image_app1, Imagick::COMPOSITE_DEFAULT, 0, 0);
		$image_app->writeimage($img_target_path);
		$image_app->destroy();

		//Generating share image

		$user_img	=	new \Imagick($img_target_path);
		$share_bg_img	=	new \Imagick($img_share);
		$share_bg_img->compositeimage($user_img, \Imagick::COMPOSITE_DEFAULT, 150, 0);
		$share_bg_img->setimagecompression(\Imagick::COMPRESSION_JPEG);
		$share_bg_img->setimagecompressionquality(90);
		$share_bg_img->writeimage($img_share_target_path);
		$user_img->destroy();
		$share_bg_img->destroy();

		unlink($tmp_path);

		return $img_target_path;
	}

	public function saveFileFromURL($url, $save_to)
	{
		$client =   new Client();
		$response = $client->get($url, ['save_to' => $save_to]);
	}

	public function saveAmazonImage($files)
	{
		$s3 =   new S3Client([
            'credentials'   => [
                'key'		=>	env('AWS_ACCESS_KEY'),
                'secret'	=>	env('AWS_SECRET_KEY')
            ],
            'version' => 'latest',
            'region'  => env('S3_REGION')
        ]);

		if( ! empty($files))
		{
			foreach($files as $file)
			{
				$s3->putObject([
					'Bucket' => env('S3_BUCKET'),
					'Key'    => env('APP_ENV').'/'.$file['filename'],
					'Body'   => fopen($file['target'], 'r'),
					'ACL'    => 'public-read',
				]);

				unlink($file['target']);
			}
		}        
        
		return env('S3_VIEW_URL').env('S3_BUCKET').'/'.env('APP_ENV').'/'.$files[0]['filename'];
	}

    public function getAmazonImage($id_user)
    {
		return [
			'profile_image' => env('S3_VIEW_URL').env('S3_BUCKET').'/'.env('APP_ENV').'/'.$id_user.'.png',
			'share_image' => env('S3_VIEW_URL').env('S3_BUCKET').'/'.env('APP_ENV').'/'.$id_user.'_share.png'
		];
    }
}