<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It is a breeze. Simply tell Lumen the URIs it should respond to
| and give it the Closure to call when that URI is requested.
|
*/



$app->get('/', ['uses' => 'HomeController@index']);

$app->post('/saveUser', [
		'uses' => 'UserController@saveUser'
	]);

$app->get('/twitterlogin', [
	'as' =>	'twitterlogin',
	'uses' => 'TwitterloginController@index'
]);

$app->get('/twitterlogin/authorized', [
	'as' =>	'twitterauth',
	'uses' => 'TwitterloginController@authorized'
]);

$app->get('/twittershare', [
	'as' =>	'twittershare',
	'uses' => 'TwitterloginController@share'
]);

$app->get('/download', [
	'as' =>	'download',
	'uses' => 'DownloadController@index'
]);


/*$app->group([  'middleware' => 'auth'], function($app)
{
	$app->get('/game', [
		'as' =>	'game',
		'uses' => 'App\Http\Controllers\GameController@index'
	]);	
});*/

// test interface controller stuff
$dev_envs	=	['local', 'development', 'staging'];

if( in_array(getenv('APP_ENV'), $dev_envs))
{
    $app->get('/users/reset', ['uses' => 'ToolboxController@reset']);
}
