<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\User;

class DownloadController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    //

    public function index(Request $request)
    {
        try
        {
            if(empty($request->get('id')) && ! ctype_digit($request->get('id')))
                throw new \Exception(trans('messages.fo_error_invalid_user'));

            $user = User::select('id_user')->where(['id_user' => $request->get('id')])->first(); 
            
            if(empty($user))
                throw new \Exception(trans('messages.fo_error_invalid_user'));

            $Utils   =   new \App\Library\Utils;
            $image = $Utils->getAmazonImage($request->get('id'));
            $download_image = $image['profile_image'];

            header('Content-type: image/png');
			header('Content-Disposition: attachment; filename="tsd-saksham.png"');
			readfile($download_image);
			exit;
        }
        catch (\Exception $e)
        {
            die($e->getMessage());
        }
    }
}
