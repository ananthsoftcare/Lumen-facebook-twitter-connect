<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;

use Abraham\TwitterOAuth\TwitterOAuth;

class TwitterloginController extends Controller
{
	private static $_twitteroauth;
	
	public function __construct()
	{
		// create twitter handle
		self::$_twitteroauth = new TwitterOAuth(conf('twitter.consumer_key'), conf('twitter.consumer_secret'));
		
		self::$_twitteroauth->host	=	'https://api.twitter.com/1.1/';
	}
	
	public function index(Request $request)
	{
		session_start();

		// get the twitter request token
		$url_authorized	=	conf('facebook.url').'twitterlogin/authorized/';

		$request_token = self::$_twitteroauth->oauth('oauth/request_token', array('oauth_callback' => $url_authorized));
		
		// if user authorized redirect the user to authorization page
		if(isset($request_token['oauth_token']) && isset($request_token['oauth_token_secret']))
		{			
			$_SESSION['oauth_token'] = $request_token['oauth_token'];
			$_SESSION['oauth_token_secret'] = $request_token['oauth_token_secret'];

			$url = self::$_twitteroauth->url('oauth/authorize', array('oauth_token' => $request_token['oauth_token']));

			return redirect($url);
			exit;
		}
		else
		{ 
			// It's a bad idea to kill the script, but we've got to know when there's an error.  
			die('Twitter authorization failed');
		}
	}
	
	public function authorized(Request $request)
	{
		$resp = $liked_count = $amazon_image = null;
		$error   = 1;
		$message = trans('messages.twitter_error_failed_connection');
		
		session_start();

		try
		{		
			if($request->get('oauth_verifier') && isset($_SESSION['oauth_token']) && isset($_SESSION['oauth_token_secret']))
			{
				// TwitterOAuth instance, with two new parameters we got in twitter_login.php  
				self::$_twitteroauth		=	new TwitterOAuth(
													conf('twitter.consumer_key'), 
													conf('twitter.consumer_secret'),
													$_SESSION['oauth_token'], 
													$_SESSION['oauth_token_secret']
												);
				
				self::$_twitteroauth->host	=	'https://api.twitter.com/1.1/';

				// Let's request the access token  
				$access_token =	self::$_twitteroauth->oauth('oauth/access_token', [
									'oauth_verifier' => $request->get('oauth_verifier')
								]);
				
				// set new oauth_token and oauth_token_secret
				if(isset($access_token['oauth_token']) && isset($access_token['oauth_token_secret']))
					self::$_twitteroauth->setOauthToken($access_token['oauth_token'], $access_token['oauth_token_secret']);
				
				// Let's get the user's info 
				$user_params = ['include_email' => 'true', 'include_entities' => 'false', 'skip_status' => 'true'];
				$user_info = self::$_twitteroauth->get('account/verify_credentials', $user_params);
				
				$data	=	[
					'first_name' =>	$user_info->name,
					'screen_name' => $user_info->screen_name,
					'id_user' => $user_info->id,
					'email'	=> $user_info->email,
					'ip' => $request->ip(),
					'ua' => $request->header('User-Agent')
				];

				User::updateOrCreate(['id_user' =>	$user_info->id], $data);

				$Utils   =   new \App\Library\Utils;
				
				$img_target_path = $Utils->saveImage($user_info->id, 'https://twitter.com/'.$user_info->screen_name.'/profile_image?size=original');
				
				if( ! file_exists($img_target_path))
					throw new \Exception(trans('messages.home_error_image_not_stored'));
				
				$img_target_path = app()->basePath('public/uploads/'.$user_info->id.'.png');
				$img_share_target_path = app()->basePath('public/uploads/'.$user_info->id.'_share.png');

				$files = [
					['target' => $img_target_path, 'filename' => $user_info->id.'.png'],
					['target' => $img_share_target_path,'filename' => $user_info->id.'_share.png']
				];

				$amazon_image = $Utils->saveAmazonImage($files);
				$images = $Utils->getAmazonImage($user_info->id);
				
				$error = 0;
				$message = trans('messages.twitter_success_connection');
			}
			else
			{
				throw new \Exception(trans('messages.twitter_error_failed_connection'));
			}

		}
		catch (\Exception $e)
		{
			die($e->getMessage());
		}

		return view('twitter', [
			'message' => $message, 
			'error' => $error, 
			'id' =>  ! empty($user_info->id) ? $user_info->id : '', 
			'profile_image' => $images['profile_image'],
			'share_image' => $images['share_image']
		]
		)->renderSections()['twitter_callback'];
	}

	public function share(Request $request)
	{
		try
		{
			if(empty($request->get('id')) && ! ctype_digit($request->get('id')))
				throw new \Exception(trans('messages.fo_error_invalid_user'));

			$id_user = User::select('id_user')->where(['id_user' => $request->get('id')])->first(); 
			
			if(empty($id_user))
				throw new \Exception(trans('messages.fo_error_invalid_user'));

			$Utils   =   new \App\Library\Utils;

			$details['title'] = trans('messages.tw_share_title');
			$details['description'] = trans('messages.tw_share_description');
			$getAmazonImage = $Utils->getAmazonImage($request->get('id'));
			$details['img_url'] = $getAmazonImage['share_image'];

			return view('partials.twittershare', ['details' => $details]);
		}
		catch (\Exception $e)
		{
			die($e->getMessage());
		}
	}
}