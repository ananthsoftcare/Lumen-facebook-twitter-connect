<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;

use Imagick;
use Aws\S3\S3Client;

class UserController extends Controller
{



public function saveUser(Request $request)
	{
        $user					=	new User;

		try
		{
            $email  =   null;

			if(empty($request->get('firstName')))
				throw new \Exception(trans('messages.home_error_empty_firstname'));

            if(empty($request->get('lastName')))
    			throw new \Exception(trans('messages.home_error_empty_lastname'));

			if( ! empty($request->get('email')))
			    $email = $request->get('email');

			if( ! empty($request->get('email')) && ! filter_var($request->get('email'), FILTER_VALIDATE_EMAIL))
				throw new \Exception(trans('messages.home_error_invalid_email'));

			if( ! app('facebook')->user)
				app('facebook')->user		=	$request->get('id_fb');

            $fb_data        =   $this->getUserFacebookDetails();

			$data	=	[
				'email'	=>	$email,
				'first_name'	=>	$request->get('firstName'),
				'last_name'	=>	$request->get('lastName'),
				'id_user'	=>	app('facebook')->user,
			    'gender' => $fb_data['gender'],
                'ip' => $request->ip(),
                'ua' => $request->header('User-Agent')
			];

			$user_info   =   User::updateOrCreate(['id_user' => app('facebook')->user], $data);

			$Utils   =   new \App\Library\Utils;
			
			$img_target_path = $Utils->saveImage(app('facebook')->user, 'http://graph.facebook.com/'.app('facebook')->user.'/picture/?width=320&height=320');

			if( ! file_exists($img_target_path))
				throw new \Exception(trans('messages.home_error_image_not_stored'));
			
			$img_target_path = app()->basePath('public/uploads/'.app('facebook')->user.'.png');
			$img_share_target_path = app()->basePath('public/uploads/'.app('facebook')->user.'_share.png');

			$files = [
				['target' => $img_target_path, 'filename' => app('facebook')->user.'.png'],
				['target' => $img_share_target_path,'filename' =>app('facebook')->user.'_share.png']
			];

			$amazon_image = $Utils->saveAmazonImage($files);
			$images = $Utils->getAmazonImage(app('facebook')->user);

            return response()->json(['success' => true, 'images' => $images]);
		}
		catch(\Exception $e)
		{
			$code	=	$e->getCode() ? $e->getCode() : 400;

			return response()->json(['error' => true, 'msg' => $e->getMessage()], $code);
		}
    }

	protected function getUserFacebookDetails()
	{
		$id_fb_user		=	app('facebook')->user;
		$accessToken	=	conf('facebook.app_id').'|'.conf('facebook.app_secret');
		$fields			=	['email', 'first_name', 'last_name', 'gender'];
		$ret			=	array_fill_keys($fields, null);

		if( ! empty($id_fb_user))
		{
			$q_graph	=	app('facebook')->getGraph('/'.$id_fb_user.'?fields='.implode(',', $fields), $accessToken);

			if(is_object($q_graph))
			{
				foreach($fields as $field)
				{
					if(isset($q_graph->$field))
						$ret[$field]	=	$q_graph->$field;
				}
			}
		}

		return $ret;
	}
}	