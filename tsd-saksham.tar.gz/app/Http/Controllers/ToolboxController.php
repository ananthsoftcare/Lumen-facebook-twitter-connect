<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Artisan;
use App\Models\Game1_User_Answer;
use App\Models\Game1_User_Instantwin;
use App\Models\Form;
use App\Models\Game1_Winner;
use App\Models\User;
use App\Models\User_Points;
use App\Models\User_Score;
use App\Models\User_Share_Tracking;
use App\Models\Game1_Slot;

class ToolboxController extends Controller
{
	public function reset(Request $request)
	{
		

		User::find(Auth::user()->id)->forceDelete();

		return response()->json(['messsage' => 'DB Cleared', 'success' => true, 'id' => Auth::user()->id]);
	}

	public function generateLabels(Request $request)
	{
		try{
		Artisan::call('build:labels');
		dd(Artisan::output());
		}
		 catch (Exception $e) {
		   return response()->json(['messsage' => $e->getMessage()], 500);
		 }
	}

    public function migrate(Request $request)
	{
        try {
            Artisan::call('migrate');
            dd(Artisan::output());
		}
        catch (Exception $e) {
            return response()->json(['messsage' => $e->getMessage()], 500);
        }
	}
}
