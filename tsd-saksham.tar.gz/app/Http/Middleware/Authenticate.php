<?php

namespace App\Http\Middleware;

use Closure;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Illuminate\Contracts\Auth\Factory as Auth;
use Illuminate\Http\RedirectResponse as IRedirectResponse;
use Illuminate\Support\Facades\Config;

class Authenticate
{
    /**
     * The authentication guard factory instance.
     *
     * @var \Illuminate\Contracts\Auth\Factory
     */
    protected $auth;

    /**
     * Create a new middleware instance.
     *
     * @param  \Illuminate\Contracts\Auth\Factory  $auth
     * @return void
     */
    public function __construct(Auth $auth)
    {
        $this->auth = $auth;
    }

    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @param  string|null  $guard
     * @return mixed
     */
    public function handle($request, Closure $next, $guard = null)
    {

        if (app('facebook')->user)
        {
            if($this->auth->guard($guard)->guest())
            {
                if($request->ajax())
                    return response()->json(['unauthorized' => true], 403);
                else
                    return redirect('/');
            }
            else
            {
                return $next($request);
            }
        }
        else // Not FB authenticated
        {
            if($request->ajax())
                return response()->json(['unauthorized' => true], 403);
            else {
                return IRedirectResponse::create('../');
            }

        }

    }
}