$(document).ready(function(){

  setTimeout(function(d){
    $("html,body").animate({scrollTop: 200}, 1000);
  }, 1000);
  setTimeout(function(d){
    $('.contentBlock').addClass('animate');
  }, 100);
});
