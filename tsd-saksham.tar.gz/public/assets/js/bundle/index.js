(function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);var f=new Error("Cannot find module '"+o+"'");throw f.code="MODULE_NOT_FOUND",f}var l=n[o]={exports:{}};t[o][0].call(l.exports,function(e){var n=t[o][1][e];return s(n?n:e)},l,l.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({1:[function(require,module,exports){
var Auth = function(){
    this.button_status  =   null;
};

Auth.prototype._busy = false;

Auth.prototype.notInFbTab = Env.fb.signedRequest.length === 0;

Auth.prototype.connect = function(e)
{
    if(navigator.userAgent.match('CriOS'))
    {
        if( ! Facebook.isUserConnected) {
            var url =   encodeURIComponent(Env.fb.callbackUrl + '/home?button_status=' + auth.button_status);
            window.location.href = 'https://m.facebook.com/dialog/oauth?display=touch&auth_type=rerequest&client_id='+Env.fb.appId+'&redirect_uri='+ url +'&scope=email,user_friends&response_type=code';
        }
        else
            auth.onConnect();
    }
    else {
        Facebook.connect(Env.fb.authScope, auth.onConnect, auth.onRefusal);
    }

	return false;
};

Auth.prototype.onConnect = function(alreadyInstalled)
{
	var _this	=	this;

    $('#home .loader').show();

    FB.api('/me?fields=email,first_name,last_name', function(response) {

		if(typeof response == 'object')
		{
            var first_name  =   response.first_name;
            var last_name   =   response.last_name;
            var email       =   response.email;

            $.ajax(
        	{
        		cache: false,
        		url: '/saveUser',
        		type: 'post',
        		dataType: 'json',
                data		:	{
        			'firstName': first_name,
        			'lastName':	last_name,
        			'email':	email,
        			'id_fb':	FB.getAuthResponse().userID,
                    'id_user_ref': window.id_user_ref
        		},
        		success: function(data)
        		{
                    if(data.success)
                    {
                        window.type = "facebook";
                        window.id_user = FB.getAuthResponse().userID;
                        window.profile_image = data.images.profile_image;
                        window.share_image = data.images.share_image;
                        
                        $('<img/>').attr('src', data.images.profile_image).load(function() {
                            $(this).remove();
                            $('#share #user_image').attr({'src' : data.images.profile_image});
                            $('#share').show();
                            $('#home, #home .loader').hide();
                        });

                        //$('#share #user_image').attr('src', data.images.profile_image);
                                            
                    }
        		},
                error: function(data) {
        			var response	=	JSON.parse(data.responseText);
                },
        		complete: function()
        		{

        		}
        	});

		}
	});
};

Auth.prototype.onRefusal = function()
{
    $('#dialog_auth').kdialog('open',
	{
		easyClose: true,
		watchForResize: true,
        wrapperClass : 'dialogAuth', 
        position : [null, "auto"],
		actionHandlers:
		{
			'continue': function ()
			{
				this.close();
				auth.connect();
			},
			'cancel': function ()
			{
				this.close();
			}
		}
	});

	auth.trackRefusal();
};

Auth.prototype.trackRefusal = function()
{
    analytics('send', 'event', '/auth_refuse', 'Facebook Auth Refuse');
};

Auth.prototype.twitterConnect = function(){ 
    window.type = "twitter";   
    window.open(Env.fb.callbackUrl + 'twitterlogin', 'twitter_login', "width=650,height=600,status=0,toolbar=0,menubar=0,resizable=0,scrollbars=no");
}

Auth.prototype.facebookShare = function()
{
    FB.ui({
        method : 'feed',
        name : Env.i18n.fb_share_title,
        link : Env.fb.callbackUrl,
        picture : window.share_image,
        caption : Env.fb.host,
        description :	Env.i18n.fb_share_discription
    },
    function(response)
    {
        if(typeof response === 'undefined' || typeof response.error_message !== 'undefined') {
            return;
        } else {
            Ga('send', 'event', 'share', 'facebook');

            if(typeof is_play !== 'undefined') {
                callback();
            }
        }
    });

    return false;
};

Auth.prototype.twitterShare = function()
{
    var link = Env.fb.callbackUrl+'twittershare?id=' + window.id_user;
    var title = Env.i18n.tw_share_top_title;
    window.open('https://twitter.com/intent/tweet?text='+encodeURIComponent(title)+'&url='+encodeURIComponent(link), 'Twitter', 'toolbar=no,location=no,directories=no,status=no,menubar=no,resizable=yes,scrollbars=no,width=500,height=350');             
};


var auth = new Auth();

function init() {
    
    analytics('send', 'pageview', {
        'page': '/Home',
        'title': 'Home'
    });

    $('#btn_connect').on('click', function(e) {
        e.preventDefault();

        analytics('send', 'event', 'facebook', 'Connect');

        auth.button_status  =   'game';
        auth.connect();
    });

    $('#btn_twitter_connect').on('click', function(e) {
        e.preventDefault();

        analytics('send', 'event', 'twitter', 'Connect');

        auth.twitterConnect();
    });

    $('#fb_share').on('click', function(e) {
        e.preventDefault();

        analytics('send', 'event', 'facebook', 'share');
        auth.facebookShare();
    });

     $('#tw_share').on('click', function(e) {
        e.preventDefault();

        analytics('send', 'event', 'twitter', 'share');

        auth.twitterShare();
    });

    $('#download').on('click', function(e) {
        e.preventDefault();

        analytics('send', 'event', 'download', 'click');
        window.open(Env.fb.callbackUrl + 'download?id=' + window.id_user);
    });


    $('#dialog_info').kdialog(
    {
        easyClose: true,
        watchForResize: true
    });
   
    if(navigator.userAgent.match('CriOS'))
    {
        setTimeout(function() {
            if(window.access_code != '' && Facebook.isUserConnected) {            
                auth.onConnect();
                window.history.pushState("", "", Env.fb.callbackUrl + 'home');
            }
            else if(window.error != '') {
                auth.onRefusal();
                window.history.pushState("", "", Env.fb.callbackUrl + 'home');
            }
        }, 1000);
    }

    window.twitterCallback = function(profile_image, share_image, id_twitter)
    {
        console.log(profile_image);
        console.log(share_image);
        console.log(id_twitter);

        window.profile_image = profile_image;
        window.share_image = share_image;
        window.id_user = id_twitter;
        $('#home .loader').show();
        $('<img/>').attr('src', profile_image).load(function() {
            $(this).remove();

            $('#share #user_image').attr({'src' : profile_image});
            $('#share').show();
            $('#home, #home .loader').hide();
        });
    }

   
}

if(window.FB)
    init();
else
    Facebook.ready(init);

},{}]},{},[1]);
