@section('twitter_callback')

<div id="message"></div>
<script>
    var profile_image = "{{$profile_image}}";
    var share_image = "{{$share_image}}";
    var message = "{{$message}}";
    var id = "{{$id}}";
    
    document.getElementById('message').innerHTML = message;

    window.opener.twitterCallback(profile_image, share_image, id);
    
    setTimeout(function(){
        window.close();
    }, 1000);
    
</script>
@endsection