<!DOCTYPE html>
<html>
    <head>        
        <title>{{$details['title']}}</title>
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:site" content="@tsdsaksham" />
        <meta name="twitter:creator" content="@FBAppsAccount" />
        <meta name="twitter:title" content="{{$details['title']}}" />
        <meta name="twitter:description" content="{{$details['description']}}" />
        <meta name="twitter:image" content="{{$details['img_url']}}" />
    </head>
    <body>
        <script type="text/javascript">
            window.location.href = "{{conf('facebook.url')}}";
        </script>
    </body>
</html>