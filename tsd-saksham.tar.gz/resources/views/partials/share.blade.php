<div>
    <img src="{{$amazon_image}}" />
</div>