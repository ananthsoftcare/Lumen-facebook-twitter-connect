<!DOCTYPE html>
<html lang="en" @if($asset == 'home') class="landing loading" @else class="loading" @endif >
	<head>
		<meta charset="UTF-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<title>{{trans('messages.app_title')}}</title>
		<link rel="shortcut icon" href="{{conf('facebook.url')}}assets/img/favicon.ico" type="image/icon">
		@if(device('isMobile'))
			<meta name="viewport" content="width=device-width,user-scalable=no,maximum-scale=1,initial-scale=1">
		@else
			<meta name="viewport" content="width=device-width,user-scalable=no,maximum-scale=1,initial-scale=1">
		@endif
		<meta property="fb:app_id" content="{{conf('facebook.app_id')}}" />
		<link href="{{conf('facebook.url')}}assets/style/build/main.css" rel="stylesheet">

		<script>
			var Env = {
				core	:	{
					cb	:	"{{conf('cb')}}",
					env :	"{{getenv('APP_ENV')}}",
					str :   "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/="
				},
				kite: {
					env: {
						dev		:	'development',
						staging	:	'staging',
						prod	:	'production'
					}
				},
				device 	: 	{
					is_mobile	: 	("{{device('isMobile')}}" === "1"),
					is_tablet	: 	("{{device('isTablet')}}" === "1"),
					lg_pad		:	("{{device('lg_pad')}}" === "1")
				},
				fb 		: 	{
					appId			: 	"{{conf('facebook.app_id')}}",
					version			: 	"{{conf('facebook.version')}}",
					locale			:	"{{conf('locale')}}",
					callbackUrl		: 	"{{conf('facebook.url')}}",
					signedRequest	: 	"{{fb()->signed_request}}",
					userId			: 	"{{fb()->user}}",
					mode			:	'{{fb()->app_mode}}',
					authScope		:	"{{conf('facebook.auth_scope')}}",
					useCookie		: 	true,
                    timestamp       :   "{{conf('timestamp')}}",
                    today_date      :   "{{conf('today_date')}}"
				},
				ga		:	{
					id	:	"{{conf('ga_id')}}"
				},
				i18n	:	{
					tw_share_top_title	:	"{{trans('messages.tw_share_top_title')}}",
					fb_share_title	:	"{{trans('messages.fb_share_title')}}",
					fb_share_discription : "{{trans('messages.fb_share_discription')}}"
				},
                asset: "{{$asset}}"
			};

		</script>

        <script src="/assets/js/preloadjs-0.6.2.min.js"></script>
		@if(getenv('APP_ENV') != 'production')
			
		@else
			<script async src="//www.google-analytics.com/analytics.js"></script>
		@endif

        <script src="/assets/js/bundle/main.js?v={{conf('cb')}}"></script>
        
	</head>

	<body>
		<div class="container site">
			<div class="logo">
				<div class="MinistryLogo">
				<img class="profilepic1" alt="profilepic" src="assets/img/mpng.png">
				</div>
				<div class="sakshamLogo">
				<img class=" profilepic" alt="profilepic" src="assets/img/saksham.png">
				</div>
				<div class="pcraLogo">
				<img class="img-responsive profilepic1" alt="profilepic" src="assets/img/pcra.png">
				</div>
			</div>

			<div class="container contentBlock" id="container">
				@yield('content')
			</div>
		</div>

		<!-- div id="terms_dialog" class="kdialog cs termsDialog" style="display: none;">
			<a href="#" data-action="close" class="closeBtn">X</a>
			<h3>{{trans('messages.home_terms_title')}}</h3>
            <div class="content">
					<ol>
	                {!! trans('messages.home_terms_desc_1') !!}
						 {!! trans('messages.home_terms_desc_2') !!}
	                {!! trans('messages.home_terms_desc_3') !!}
	                {!! trans('messages.home_terms_desc_4') !!}
	                {!! trans('messages.home_terms_desc_5') !!}
				 	</ol>
            </div>

		</div -->
		
	</body>
</html>
